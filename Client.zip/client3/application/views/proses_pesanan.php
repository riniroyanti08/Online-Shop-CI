
<div class="container-fluid text-dark">
	<div class="alert alert-success text-dark">
		<h4 class="text-center align-middle">Selamat, Pesanan Anda telah Berhasil diproses!!!</h4>
		<center><button class="btn btn-primary text-dark "><a style="text-decoration: none; color: white;" href="<?php echo site_url('welcome') ?>">Kembali ke Halaman Utama</a></center></button>
	</div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>