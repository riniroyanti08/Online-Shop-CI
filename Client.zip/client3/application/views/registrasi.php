<body class="bg-light">

  <div class="container">

   
              <div class="text-center pt-5 text-dark">
                <h1 class="h4  mb-4">Daftar Akun</h1>
              </div>
              <form method="post" action="<?php echo base_url('registrasi/index') ?>" class="user">

                <div class="form-group">
                  <input type="text" class="form-control form-control-user" id="exampleInputEmail" placeholder="Nama Anda" name="nama">

                  <?php echo form_error('nama', '<div class="text-danger small ml-2">', '</div>') ?>
                </div>
                
                <div class="form-group">
                  <input type="text" class="form-control form-control-user" id="exampleInputEmail" placeholder="Username Anda" name="username">
                  <?php echo form_error('username', '<div class="text-danger small ml-2">', '</div>') ?>
                </div>

                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password" name="password_1">
                    <?php echo form_error('password_1', '<div class="text-danger small ml-2">', '</div>') ?>
                  </div>

                  <div class="col-sm-6">
                    <input type="password" class="form-control form-control-user" id="exampleRepeatPassword" placeholder="Ulangi Password" name="password_2">
                  </div>
                </div>
                <button type="submit" class="btn btn-success btn-user btn-block">Daftar Akun</button>
              
              </form>
              <hr>
              
              <div class="text-center">
                <a class="small" href="<?php echo base_url('auth/login') ?> ">Sudah Punya Akun? Silahkan Login</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <br><br>
  <br>
  <br>
  <br>
  


