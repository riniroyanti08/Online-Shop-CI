<!DOCTYPE html>
<html>
<head>
 <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Amado - Furniture Ecommerce Template | Home</title>

    <!-- Favicon  -->
    <link rel="icon" href="<?php echo base_url()?>assets/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/core-style.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/style.css">
     <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="<?php echo base_url()?>assets/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="<?php echo base_url()?>assets/js/plugins.js"></script>
    <!-- Active js -->
    <script src="<?php echo base_url()?>assets/js/active.js"></script>

</head>
<body>
<!-- Footer -->
<br><br><br>
<div class="">
  
    
    
    
          <ul class="list-unstyled list-inline social text-center">
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
          </ul>
          <div class="col-xs-12 col-sm-12 col-md-12 mt-2 text-center text-dark">
          <p class="text-dark"><u>Proyek Kerja kelompok Pemrograman Web Lanjutan</p>
          <p class="h6 text-dark">&copy All right Reversed.<a class="text-dark ml-2"></a></p>
        </div>
        </div>

        </hr>
      </div> 
  </div>
</nav>


        
    
</body>
</html>
