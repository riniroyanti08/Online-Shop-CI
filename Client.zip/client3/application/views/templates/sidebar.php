<!DOCTYPE HTML>
<head>
    <title>Store Website</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="<?php echo base_url() ?>assets/css/logo.css" rel="stylesheet" type="text/css" media="all"/>

    <link href="<?php echo base_url() ?>assets/web/css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="<?php echo base_url() ?>assets/web/css/menu.css" rel="stylesheet" type="text/css" media="all"/>
    <script src="<?php echo base_url() ?>assets/web/js/jquerymain.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/web/js/jquery-1.7.2.min.js"></script> 
    <script type="text/javascript" src="<?php echo base_url() ?>assets/web/js/nav.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/web/js/move-top.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/web/js/easing.js"></script> 
    <script type="text/javascript" src="<?php echo base_url() ?>assets/web/js/nav-hover.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
    
</head>
<body>

      <!-- Main Content -->
      <div id="content">
        <div class="container-fluid">

        <!-- Topbar -->
       
          <nav class="navbar navbar-expand-lg navbar-dark bg-light topbar mb-4 ">
          <div class="logo">
            <div class="amado-navbar-brand">

            <img src="<?php echo base_url()?>assets/img/core-img/logo.png" alt="">
          </div>

                <!-- <img src="<?php echo base_url(); ?>assets/img/fnt.png"> -->


            </div>
          <!-- Sidebar Toggle (Topbar) -->
         

          <!-- Topbar Search -->
          

          <!-- Topbar Navbar -->
         

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            


            
           <ul class=" shopping_cart ml-auto">
             <div class="cart" >
                        <a  href="<?php echo base_url('cart');?>" title="View my shopping cart" rel="nofollow">
                             <?php
                  $keranjang = ''.$this->cart->total_items(). ' items' 
                  ?>

                  <?php echo anchor('dashboard/detail_keranjang', $keranjang) ?>
                        </a>
                    </div>
             
           </ul>

               <div class="topbar-divider d-none d-sm-block"></div>

           <div class="topbar-divider d-none d-sm-block"></div>

           <ul class=" navbar-nav ml-right ">
             <?php if($this->session->userdata('username')) { ?>
               <li><h6>Selamat Datang&nbsp;<?php echo $this->session->userdata('username') ?></h6></li> &nbsp;   
               <li class="btn btn-primary"><?php echo anchor('auth/logout','Logout', array('class' => 'text-white', )); ?></li> <?php } else { ?>
                 <li class="btn btn-primary"><?php echo anchor('auth/login', 'Login', array('class' => 'text-white', )); ?></li>
               <?php } ?>
             
           </ul>
           
           
            </div>


           
         

        </nav>
        <!-- End of Topbar -->


      </body>
      </html>