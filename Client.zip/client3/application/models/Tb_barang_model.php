<?php

class Tb_barang_model extends CI_Model 
{
	public function getTb_barang($id_brg = null)
	{
		if( $id_brg === null) {
			return $this->db->get('tb_barang')->result_array();
		} else {
			return $this->db->get_where('tb_barang', ['id_brg' => $id_brg])->result_array();
		}
		
	}

	public function deleteTb_barang($id_brg)
	{
		$this->db->delete('tb_barang', ['id_brg' => $id_brg]);
		return $this->db->affected_rows();
	}

	public function createTb_barang($data)
	{
		$this->db->insert('tb_barang', $data);
		return $this->db->affected_rows();
	}

	public function updateTb_barang($data, $id_brg)
	{
		$this->db->update('tb_barang', $data, ['id_brg' => $id_brg]);
		return $this->db->affected_rows();
	}

}
 