<?php

class Model_kategori extends CI_Model{

	public function data_standing(){
		return $this->db->get_where("tb_barang", array('kategori' => 'Furniture Free Standing'));
	}

	public function data_knockdown(){
		return $this->db->get_where("tb_barang", array('kategori' => 'Furniture Knockdown'));
	}

	public function data_mobile(){
		return $this->db->get_where("tb_barang", array('kategori' => 'Furniture Mobile'));
	}
}