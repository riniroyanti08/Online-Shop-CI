<?php 

class Kategori extends CI_Controller{
	public function __construct()
{
    parent::__construct();
    $this->load->helper('my_helper');
    no_cache();

}
	public function standing()
	{
		$data['standing'] = $this->model_kategori->data_standing()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('standing',$data);
		$this->load->view('templates/footer');
	}

	public function knockdown()
	{
		$data['knockdown'] = $this->model_kategori->data_knockdown()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('knockdown',$data);
		$this->load->view('templates/footer');
	}

	public function mobile()
	{
		$data['mobile'] = $this->model_kategori->data_mobile()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('mobile',$data);
		$this->load->view('templates/footer');
	}
} 