<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller 
{
	var $API ="";
	function __construct()
	{
		parent::__construct();
		$this->API="http://192.168.43.103/Server/index.php";
		$this->load->library('session');
		$this->load->library('curl');
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('model_barang');
	}

	public function index()
	{
		$data['barang'] = json_decode($this->curl->simple_get($this->API.'/api'));
		//$data['barang'] = $this->model_barang->tampil_data()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('dashboard',$data);
		$this->load->view('templates/footer');
	}
}
